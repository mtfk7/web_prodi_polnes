import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { ProgramHighlights } from "@/components/program-highlights"
import { VisionMission } from "@/components/vision-mission"
import { DepartmentProfile } from "@/components/department-profile"
import { Facilities } from "@/components/facilities"
import { Achievements } from "@/components/achievements"
import { SupportedBy } from "@/components/supported-by"
import { StudentProjects } from "@/components/student-projects"
import { GraduateResults } from "@/components/graduate-results"
import { HowToApply } from "@/components/how-to-apply"
import { Footer } from "@/components/footer"
import { BackToTop } from "@/components/back-to-top"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <Hero />
      <VisionMission />
      <DepartmentProfile />
      <ProgramHighlights />
      <Facilities />
      <Achievements />
      
      <StudentProjects />
      <SupportedBy />
      <GraduateResults />
      <HowToApply />
      <Footer />
      <BackToTop />
    </div>
  )
}
