export const lecturers = [
  {
    name: "Rheo Malani, S.Kom, M.Kom",
    position: "Kajur & Dosen Prodi TI",
    photo: "/dosen/rheo.jpg",
  },
  {
    name: "Mulyanto, S.Kom., M.Cs",
    position: "Sekjur & Dosen Prodi TI",
    photo: "/dosen/mulyanto.jpg",
  },
  {
    name: "Fransisca Angelia Sebayang, S.Kom, M.Kom",
    position: "Dosen Prodi TI",
    photo: "/dosen/fransisca.jpg",
  },
  {
    name: "Fajerin Biabdillah, M.Kom",
    position: "Dosen Prodi TI",
    photo: "/dosen/fajerin.jpg",
  },
  {
    name: "M. Taufiq Sumadi, S.Tr.Kom, M.Tr.Kom",
    position: "Dosen Prodi TI",
    photo: "/dosen/taufiq.jpg",
  },
  {
    name: "Bedi Suprapty, S.Kom., M.Kom.",
    position: "Dosen Prodi TI",
    photo: "/dosen/bedi.jpg",
  },
  {
    name: "Aam Shodiqul Munir, S.Kom, M.Kom",
    position: "Dosen Prodi TI",
    photo: "/dosen/aam.jpg",
  },
  {
    name: "Achmad Fanany Onnilita Gaffar, ST., MT.",
    position: "Dosen Prodi TI",
    photo: "/dosen/achmad.jpg",
  },

  {
    name: "Arief Bramanto Wicaksono Putra, S.ST., MT",
    position: "Kaprodi TI",
    photo: "/dosen/arief.jpg",
  },
  {
    name: "Dwi Titi Maesaroh, S.Pd., M.Pd.",
    position: "Dosen Prodi TI",
    photo: "/dosen/dwi.jpg",
  },

  {
    name: "Asrina Astagani, ST., MT",
    position: "Dosen Prodi TI",
    photo: "/dosen/asrina.jpg",
  }
];