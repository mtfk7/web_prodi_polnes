// Data dosen dan staff berdasarkan data terbaru
export const lecturers = [


  // Kaprodi
  {
    name: "Agusdi Syafrizal, S.Kom., M.T",
    position: "Kaprodi TIM & Dosen Prodi TIM",
    photo: "/dosen/agusdi.jpg",
  },
  {
    name: "Farindika Metandi, BCompSc., MM., M.Cs.",
    position: "Kalab Software & Dosen Prodi TIM",
    photo: "/dosen/farindika.jpg",
  },
  {
    name: "Subhan Hartanto, M.Kom",
    position: "Kalab Multimedia & Dosen Prodi TIM",
    photo: "/dosen/subhan.jpg",
  },
  {
    name: "M. Zainul Rohman, SST., MT.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/zain.jpg",
  },
  {
    name: "Anton Topadang, S.Kom., M.Cs.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/anton.jpg",
  },
  {
    name: "Bambang Cahyono, S.Pd., M.Kom",
    position: "Dosen Prodi TIM",
    photo: "/dosen/bambang.jpg",
  },
  {
    name: "Damar Nucahyono, ST., M.Eng.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/damar.jpg",
  },
  {
    name: "M. Farman Andrijasa, S.Kom., M.Kom.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/farman.jpg",
  },
  {
    name: "Noor Alam Hadiwijaya, ST., M.Cs.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/noor.jpg",
  },
  {
    name: "Tommy Bustomi, S.Kom., M.Kom.",
    position: "Dosen Prodi TIM",
    photo: "/dosen/tommy.jpg",
  },
  {
    name: "Yusni Nyura, S.Kom., M.Kom",
    position: "Dosen Prodi TIM",
    photo: "/dosen/yusni.jpg",
  },
  {
    name: "Muhammad Bagus Bintang Timur, S.Kom",
    position: "Dosen Prodi TIM",
    photo: "/dosen/bintang.jpg",
  },
]
