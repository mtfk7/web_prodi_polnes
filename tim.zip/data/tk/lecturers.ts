export const lecturers = [
  {
    name: "Agusma Wajiansyah, SST., MT.",
    position: "Kaprodi TK",
    photo: "/dosen/agusma.jpg",
  },
  {
    name: "Mulyanto, S.Kom., M.Cs",
    position: "Sekjur & Dosen Prodi TK",
    photo: "/dosen/mulyanto.jpg",
  },
  {
    name: "Ansar Rizal, ST., M.Kom",
    position: "Dosen Prodi TK",
    photo: "/dosen/ansar.jpg",
  },
  {
    name: "Didikus Susilo Budi Utomo, ST., M.Sc",
    position: "Dosen Prodi TK",
    photo: "/dosen/didi.jpg",
  },
  {
    name: "Dwi Titi Maesaroh, S.Pd., M.Pd.",
    position: "Dosen Prodi TK",
    photo: "/dosen/dwi.jpg",
  },
  {
    name: "Fajerin Biabdillah, M.Kom",
    position: "Dosen Prodi TK",
    photo: "/dosen/fajerin.jpg",
  },
  {
    name: "Hari Purwadi, ST., MT.",
    position: "Dosen Prodi TK",
    photo: "/dosen/hari.jpg",
  },
  {
    name: "M. Taufiq Sumadi, S.Tr.Kom, M.Tr.Kom",
    position: "Dosen Prodi TK",
    photo: "/dosen/taufiq.jpg",
  },
  {
    name: "Rihartanto, ST.",
    position: "Dosen Prodi TK",
    photo: "/dosen/rihartanto.jpg",
  },
  {
    name: "Supriadi, SST., MT.",
    position: "Kalab Mekatronika",
    photo: "/dosen/supriadi.jpg",
  }
];