export const lecturers = [
  // Pimpinan
  {
    name: "Ahmad Rofiq Hakim, S.Pd., M.Kom.",
    position: "Kaprodi TRK & Dosen Prodi TRK",
    photo: "/dosen/rofiq.jpg",
  },

  // Kalab
  {
    name: "Agus Triyono, ST, MT",
    position: "Kalab Hardware & Dosen Prodi TRK",
    photo: "/dosen/agus.jpg",
  },

  // Dosen Prodi TRK
  {
    name: "Karyo Budi Utomo, S.Kom., M.Eng.",
    position: "Wakil Direktur 2 POLNES & Dosen Prodi TRK",
    photo: "/dosen/karyo.jpg",
  },
  {
    name: "M. Zainul Rohman, SST., MT.",
    position: "Dosen Prodi TRK",
    photo: "/dosen/zain.jpg",
  },
  {
    name: "Abdullah Hanif, S.Kom, M.Kom",
    position: "Dosen Prodi TRK",
    photo: "/dosen/abdullah.jpg",
  },
  {
    name: "Arsan Kumala Jaya, M.T",
    position: "Dosen Prodi TRK",
    photo: "/dosen/arsan.jpg",
  },
  {
    name: "Fara Triadi, M.T",
    position: "Dosen Prodi TRK",
    photo: "/dosen/fara.jpg",
  },
  {
    name: "Wahyuni Eka Sari, S.Kom., M.Eng",
    position: "Dosen Prodi TRK",
    photo: "/dosen/wahyuni.jpg",
  },
  {
    name: "Irwansyah, S.Kom, M.Cs",
    position: "Dosen Prodi TRK",
    photo: "/dosen/irwansyah.jpg",
  },
  {
    name: "Muhammad Bagus Bintang Timur, S.Kom",
    position: "Dosen Prodi TRK",
    photo: "/dosen/bintang.jpg",
  },
]